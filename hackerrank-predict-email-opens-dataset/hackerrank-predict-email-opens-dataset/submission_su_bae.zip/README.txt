1. Run main.py
2. Currently all input and output file names are hardcoded